function y = fitlabelprop(sigma,X,slabel,label)
    owner = gpulabelprop(X,slabel,sigma);
    y = 1-stmwevalk(label,slabel,owner);
end