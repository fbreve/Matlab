for i=1:10000000
    prob = cumsum(graph(2,:));
end