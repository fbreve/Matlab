correl=zeros(10);
for l=1:1484
    for i=1:10
        for j=(i+1):10
            correl(i,j) = correl(i,j) + (1-abs(owndeg(l,i)-owndeg(l,j)));
        end
    end
end
for i=1:10
    for j=(i+1):10
        correl(j,i) = correl(i,j);
    end
end
