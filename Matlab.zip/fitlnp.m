function y = fitlnp(k,X,slabel,label)
    k = round(k);
    owner = gpulnp(X,slabel,k);
    y = 1-stmwevalk(label,slabel,owner);
end