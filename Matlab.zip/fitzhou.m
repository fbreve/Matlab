function y = fitzhou(sigma,X,slabel,label)
    owner = gpuzhou(X,slabel,sigma);
    y = 1-stmwevalk(label,slabel,owner);
end