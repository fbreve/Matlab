color = owner./3;
%scatter(X(:,1),X(:,2),[],color)